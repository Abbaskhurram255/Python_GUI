import re
from sys import argv
from numbers import Number
from typing import *

def execute(filename: str) -> None:
    keys = {
        # functions, and classes
        "cls": "class",
        "_ctr": "def __init__",
        "_make": "def __init__",
        "_init": "def __init__",
        "_constr": "def __init__",
        "fc": "def",
        "ret": "return",
        "on_start": "if __name__ == '__main__'",
        "is_main": "if __name__ == '__main__'",
        # math
        "^": "**",
        "pow": "**",
        "div": "/",
        "times": "*",
        "tms": "*",
        "mul": "*",
        "plus": "+",
        "pls": "+",
        "minus": "-",
        "mns": "-",
        # other
        "agar": "if",
        "aur": "and",
        "ya": "or",
        "nahi": "not",
        "he": "==",
        "har": "for",
        "andar": "in",
        "limit": "range",
        "ke": "",
        "ruko": "break",
        "ignore": "continue",
        # types
        "var ": "",
        "lafz": "str",
        "jumla": "str",
        "nr": "Number",
    }
    with open(filename, "r") as file:
        code = file.read()
        # Remove strings
        strings = re.findall(r"\"[^\"]*\"", code)
        for i, string in enumerate(strings):
            code = code.replace(string, f"__STRING_{i}__")
        # Replace keywords
        for key, value in keys.items():
            code = re.sub(r"\b(" + re.escape(key) + r"(?!\s*[:=])|(?<=:)" + re.escape(key) + "|(?<=:\s)" + re.escape(key) + ")\b", value, code)
        # Restore strings
        for j, string in enumerate(strings):
            code = code.replace(f"__STRING_{j}__", string)
        print("Translation:\n________________\n\n", code)
        namespace:obj = {"Number": Number, "__name__": "__main__"}
        exec(code, namespace)

def main() -> None:
    arg: str
    arg = argv[1] if len(argv) >= 2 else "test.klang"
    execute(arg)

if __name__ == "__main__":
    main()