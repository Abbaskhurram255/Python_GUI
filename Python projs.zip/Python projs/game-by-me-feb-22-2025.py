from threading import Timer

score = 0
# score, as usual, 0 se hi shuru hota he
speed = 0
# speed bhi rest me he
velocity = {"x": 0, "y": 0, "z": 0}
# velocity or speed sath sath chalne wale hen <fark sirf itna he ke speed angle-based nahi hoti, ek car game me velocity y barh rahi he agar ^ press karne par, to <> press karne par velocity x, yani horizontal veloxity, barhni chahie>
position = {"x": 0, "y": 0, "z": 0}
# speed agar 5 ki chal rahi he, to vehicle me wazan bhi to hota he... position 4.9 rakhege ham screen pe, take realistic feel ae
enemy_position = {"x": 20, "y": -60, "z": 0}

def refresh_x_velocity():
	def fn():
		velocity["x"] = 0
	t = Timer(2.0, fn)
	t.start()
	
print("\n")
print("\t  B B B    _____   K    K    EEEEE    RRRRR")
print("\t  B    B     |     K   K    E         R    R")
print("\t  B   B      |     K  K     E         R  R")
print("\t  B BB       |     KK       EEEEE     RRR")
print("\t  B    B     |     K K      E         R   R")
print("\t  B   B      |     K  K     E         R    R")
print("\t  B B      |||||   K    K    EEEEE    R     R")
print("\n\n\t\t      == Version 1.0.0 ==\n\n\n")

user_name = input("\tPlease enter a username: ").strip() or "Kamran"
# user_name mile to theek, nahi to play as "Kamran"

print("\t§ Welcome Aboard, @%s" % user_name)
print("\t___ Mojooda Score, or Speed ___")
print("\tScore: ", score)
print("\tSpeed: ", speed)
print("\tVelocity: {")
print("\t    x: ", velocity["x"])
print("\t    y: ", velocity["y"])
print("\t    z: ", velocity["z"])
print("\t}")
print("\tPosition: {")
print("\t    x: ", position["x"])
print("\t    y: ", position["y"])
print("\t    z: ", position["z"])
print("\t}")

key_baar_baar_puchte_raho = True

while key_baar_baar_puchte_raho == True:
    # agar key UP, ya key W ko press kia jae , to speed ko +5 karke barhao, and score +2 +2 karke, har accelerator press pe
    
	dabai_gai_key = input("\tPlease enter a key: ").strip()
	# Program ko kya bataya jaraha he yaha: konsi key press ki gai he? Pata karo zara!
	
	acceleration_wali_key = "up"
	acceleration_wali_key2 = "w"
	acceleration_wali_key3 = "^"
	double_acceleration = "^^"
	triple_acceleration = "^^^"
	turbo_acceleration = "*"
	# agar key "UP", "W", "w", ya "^" enter ki jae, tab hi score or speed ko barhao, warna rehne do <agar key kuch or press ki gai he, to score or speed ko 0 hi rehne do>
	# filhal ham key UP | up | ^ pe hi kaam karne wale hen, left, right, or down is program ko lakba kardenge, pehle se hi mene itna complex bana dia he
	left_wali_key = "left"
	left_wali_key2 = "a"
	left_wali_key3 = "<"
	double_left = "<<"
	top_left = "^<"
	
	right_wali_key = "right"
	right_wali_key2 = "d"
	right_wali_key3 = ">"
	double_right = ">>"
	top_right = "^>"
	
	down_wali_key = "down"
	down_wali_key2 = "s"
	down_wali_key3 = "√"
	double_brake = "√√"
	unsafe_front_brake = "√√√"
	# down wali key ke lie √<root> sign use karlete he, maslan
	
	dabai_gai_key = dabai_gai_key.lower()
	# key ko lowercase kar lete hen, take wo W or w, UP, up, or ^, sab hi ke lie kaam kare
	if speed <= 90:
		#handle +y <acceleration>
		if dabai_gai_key == acceleration_wali_key or dabai_gai_key == acceleration_wali_key2 or dabai_gai_key == acceleration_wali_key3:
		    speed += 5
		    velocity["y"] += 5
		    position["y"] += 5*.98
		    score += 2
		    
		elif dabai_gai_key == double_acceleration:
			if speed >= 10:
			    speed += 10
			    velocity["y"] += 10
			    position["y"] += 10*.98
			    score += 4
		    
		elif dabai_gai_key == triple_acceleration:
			if speed >= 20:
			    speed += 18
			    velocity["y"] += 18
			    position["y"] += 18*.98
			    score += 8
		    
		elif dabai_gai_key == turbo_acceleration:
			if speed >= 40:
			    speed += 25
			    velocity["y"] += 25
			    position["y"] += 24*.98
			    score += 16
		
		#handle -x
		elif dabai_gai_key == left_wali_key or dabai_gai_key == left_wali_key2 or dabai_gai_key == left_wali_key3:
		    if speed and position["x"] > -30 and velocity["y"] > 0:
		        velocity["x"] -= 5
		        refresh_x_velocity()
		        position["x"] -= 4.9
		        score += .5
		        
		elif dabai_gai_key == double_left:
		    if speed and position["x"] > -30 and velocity["y"] > 0:
		        if velocity["y"] < 90:
		            velocity["x"] -= 10
		            refresh_x_velocity()
		            position["x"] -= 9.8
		            score += .5
		        else:
		        	print("\tCRASH! Score: ", int(score))
		        	break
		        
		 # handle +x
		elif dabai_gai_key == right_wali_key or dabai_gai_key == right_wali_key2 or dabai_gai_key == right_wali_key3:
		    if speed and position["x"] < 30 and velocity["y"] > 0:
		        velocity["x"] += 5
		        refresh_x_velocity()
		        position["x"] += 4.9
		        score += .5
		        
		elif dabai_gai_key == double_right:
		    if speed and position["x"] < 30 and velocity["y"] > 0:
		        if velocity["y"] < 90:
		            velocity["x"] += 10
		            refresh_x_velocity()
		            position["x"] += 9.8
		            score += .5
		        else:
		        	print("\tCRASH! Score: ", int(score))
		        	break
		        
		 # handle -y <braking>
		elif dabai_gai_key == down_wali_key or dabai_gai_key == down_wali_key2 or dabai_gai_key == down_wali_key3:
		    if speed and velocity["y"]-2.5 >= 0:
		        speed -= 2.5
		        velocity["y"] -= 2.5
		        position["y"] += velocity["y"] * .07
		        score += .5
		        
		elif dabai_gai_key == double_brake:
		    if speed and velocity["y"]-5 >= 0:
		        speed -= 5
		        velocity["y"] -= 5
		        position["y"] += velocity["y"] * .035
		        score += .75
		        
		elif dabai_gai_key == unsafe_front_brake:
		    if speed and velocity["y"] >= 0:
		        if velocity["y"] >= 60:
		            print("\tNot the best timing for a front break!\n\tCrash ☠️\n\tScore: ", round(score))
		            break
		        else:
		            speed -= 20
		            velocity["y"] -= 20
		            position["y"] += velocity["y"] * .00875
		            score += 1
		        
		else: print("\tInvalid key!")
	else:
		if position["x"] >= enemy_position["x"]:
			print("\tCRASH! Score: ", round(score))
			break
		else:
			print("\tAre you looking for trouble?\n\tApply some brakes, dammit! Look, there's a car\n\ton the right!")
			enemy_position = {"x": 5, "y": 0, "z": "0"}
			
			#handle -x, even at the high speed
			if dabai_gai_key == left_wali_key or dabai_gai_key == left_wali_key2 or dabai_gai_key == left_wali_key3:
			    if speed and position["x"] > -30 and velocity["y"] > 0:
			        velocity["x"] -= 5
			        refresh_x_velocity()
			        position["x"] -= 4.9
			        score += .5
			        
			 # handle +x, even at the highest speed
			elif dabai_gai_key == right_wali_key or dabai_gai_key == right_wali_key2 or dabai_gai_key == right_wali_key3:
			    if speed and position["x"] < 30 and velocity["y"] > 0:
			        velocity["x"] += 5
			        refresh_x_velocity()
			        position["x"] += 4.9
			        score += .5
			        
			elif dabai_gai_key == down_wali_key or dabai_gai_key == down_wali_key2 or dabai_gai_key == down_wali_key3:
			    if speed and velocity["y"]-2.5 >= 0:
			        speed -= 2.5
			        velocity["y"] -= 2.5
			        position["y"] += velocity["y"] * .07
			        score += .5
			        
			elif dabai_gai_key == double_brake:
			    if speed and velocity["y"]-5 >= 0:
			        speed -= 5
			        velocity["y"] -= 5
			        position["y"] += velocity["y"] * .035
			        score += .75
			        
			elif dabai_gai_key == unsafe_front_brake:
			    if speed and velocity["y"] >= 0:
			        if velocity["y"] >= 60:
			            print("\tNot the best timing for a front break.\n\tCrash ☠️\n\tScore: ", round(score))
			            break
			        else:
			            speed -= 20
			            velocity["y"] -= 20
			            position["y"] += velocity["y"] * .00875
			            score += .8
	
	
	print("\t___ Naya score <keypress ke bad>___")
	print("\tNew Score: ", score)
	print("\tNew Speed: ", speed)
	print("\tNew velocity: {")
	print("\t    x: ", velocity["x"])
	print("\t    y: ", velocity["y"])
	print("\t    z: ", velocity["z"])
	print("\t}")
	print("\tNew position: {")
	print("\t    x: ", position["x"])
	print("\t    y: ", position["y"])
	print("\t    z: ", position["z"])
	print("\t}")