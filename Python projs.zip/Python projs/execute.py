import sys
from tokenize import tokenize, untokenize

def execute(filename: str) -> None:
	keys = {
		"agar": "if",
		"he": "==",
		"har": "for",
		"andar": "in",
		"limit": "range",
		"ke": "",
		"ruko": "break",
		"ignore": "continue",
		"dikhao": "print"
    }
	with open(filename, "rb") as file:
		tokens = []
		for token in tokenize(file.readline):
			t = (token.type, keys[token.string] if token.string in keys else token.string)
			tokens.append(t)
		translation = untokenize(tokens).decode("utf-8")
		exec(translation)
    
def main() -> None:
	arg: str = sys.argv[1]
	execute(arg)
	
if __name__ == "__main__":
	main()