# Python ko Hindi kese banaya jae?
# Here's how:
kaho = batao = ab = say = design = print
pucho = suno = input
def kism(x, y=""):
	if not x:
		return None
	if not y or (type(y) != str and type(y) != type):
		return str(type(x)).split(" '")[1].split("'>")[0]
	return type(x) == y if type(y) == type else kism(x) == y
he_kism = kism
lambai = len
linechoro = linebreak = "\n"
karibi = round
def ulta(x):
	x = [*x]
	x.reverse()
	return "".join(x)
def chota_lo(n1, n2): return f"{min(n1, n2)} chota he {max(n1, n2)} se"
def bara_lo(n1, n2): return f"{max(n1, n2)} bara he {min(n1, n2)} se"
chota_wala = chota_lo
bara_wala = bara_lo
chaarspaces = "\t"


kaho("Hi yar")
naam = suno("Naam batao zara apna? ")
umr = pucho("Umr? ")

def he(a, b): return a.lower() == b.lower()
def nahi(x): return not(x)

design(" --- * * --- ")
kaho("Naam: ", naam)
# hen kitne characters lekin naam me, space milaake?
kaho(f"<{lambai(naam)} lambai he jis ke naam ki>")
batao("Umr: ", umr)
ab(linechoro)
batao("Lo line bhi chor di <for change of context>")
say("* Compare two numbers *")
ab(chota_lo(5, 15))
kaho("or")
ab(bara_wala(-5, 8))
ab(linechoro)
if (he(naam, "hifazat")):
	kaho("+1, name's", naam)
if (nahi(he(naam, "hifazat"))):
	kaho("0, koi or")
if (he(naam, ulta("hifazat"))):
	kaho("-1 Abe o, ulta nahi likhte")
ab(linechoro)
ab(he_kism(naam, str))
ab(he_kism(naam, "int"))